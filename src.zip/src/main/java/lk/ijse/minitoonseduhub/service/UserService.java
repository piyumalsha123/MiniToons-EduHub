package lk.ijse.minitoonseduhub.service;

import lk.ijse.minitoonseduhub.dto.AuthDto;
import lk.ijse.minitoonseduhub.dto.AuthResponseDto;
import lk.ijse.minitoonseduhub.dto.RegisterDto;
import lk.ijse.minitoonseduhub.entity.Role;
import lk.ijse.minitoonseduhub.entity.User;
import lk.ijse.minitoonseduhub.repository.UserRepository;
import lk.ijse.minitoonseduhub.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    // ============================
    // REGISTER
    // ============================
    public String saveUser(RegisterDto dto) {

        if (userRepository.findByUsername(dto.getUsername()).isPresent()) {
            throw new RuntimeException("Username already exists");
        }

        Role role;
        try {
            role = Role.valueOf(dto.getRole().toUpperCase());
        } catch (Exception e) {
            throw new RuntimeException("Invalid role (ADMIN, PARENT, CHILD only)");
        }

        User user = User.builder()
                .username(dto.getUsername())
                .password(passwordEncoder.encode(dto.getPassword()))
                .role(role)
                .build();

        userRepository.save(user);

        return "User Registered Successfully";
    }

    // ============================
    // LOGIN
    // ============================
    public AuthResponseDto authenticate(AuthDto dto) {

        User user = userRepository.findByUsername(dto.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        String token = jwtUtil.generateToken(
                user.getUsername(),
                "ROLE_" + user.getRole().name()
        );

        return new AuthResponseDto(token);
    }
}