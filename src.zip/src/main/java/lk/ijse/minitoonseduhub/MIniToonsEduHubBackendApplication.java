package lk.ijse.minitoonseduhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MIniToonsEduHubBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(MIniToonsEduHubBackendApplication.class, args);
    }

}
